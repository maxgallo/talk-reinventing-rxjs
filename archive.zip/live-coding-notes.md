# Live Coding notes

- Do not copy and paste, NEVER
- Real code on the side with iPad
- Keep full implementation opened in another tab --> Autocompletion
- VIM
    - ALEDisable

## MobX

1. `autorun` tracks all the accesses and store the reaction
2. the `setters` will trigger all the reactions

## RxJS

1. `from` as first observable
2. abstract `createObservable` function
3. `pipe` with 1 `map`
4. multiple `map`s
5. multiple `map`s & `filter`
